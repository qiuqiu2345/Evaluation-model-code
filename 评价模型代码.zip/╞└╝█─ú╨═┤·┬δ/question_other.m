clc;clear ;close all
data_table=readtable('附件1 近5年402家供应商的相关数据.xlsx','Sheet','企业的订货量（m³）');
data_table1=readtable('附件1 近5年402家供应商的相关数据.xlsx','Sheet','供应商的供货量（m³）');
%% 将文字标签修改为数字标签
data_abc=data_table(:,2);%将第2列取出来，data_table(2,:)%将第2行取出来(2,3)
data_abc_num=table2array(data_abc);  % 表文件转化为cell
data_tongji=tabulate(data_abc_num)%   统计ABC个数
for i=1:size(data_tongji,1)
dianli_str{1,i}=data_tongji{i,1};
end
data_shuju=zeros(length(data_abc_num),1);
for NN=1:length(dianli_str)
    idx = find(ismember(data_abc_num, dianli_str{1,NN} ));
    data_shuju(idx)=NN;
end
%%
%将ABC找出来分开评价
for i=1:size(data_tongji,1)  %将不同标签行的位置分别找出来存在不同的元胞里，因为维度不一样
    A(i)={find(data_shuju==i)};
end
%%
B_data=data_table(A{1,1},:);
A_data=data_table(A{1,2},:);
%% 表格有用的数据变成矩阵数据
data=table2array(data_table(:,3:end));
data1=table2array(data_table1(:,3:end));
data_test=data;       %企业订单数
data_test1=data1;   %企业供货数
    %%
  %index1 供货次数
    for k=1:size(data_test1,1)
        AA=1:size(data_test,2);
        AA1=find(data_test(k,:)~=0);
    B(k,1)=length(AA1);  %指标1各供应商供应可靠度
    end
  %index2 供应商最大供给
    B(:,2)=max(data_test1');  %指标2各供应商的供给
   %index3 供应商平均供给
   B(:,3)=mean(data_test1');  %指标3企业对供应商周平均订货
   
   %供给是否可靠
     B(:,4)=mean(data_test1'-data_test');  %指标3企业对供应商周平均订
   %index5 供应商平均波动
    C=[];
    for j=1:size(data_test1,1)  
        for m=1:size(data_test1,2)
        C(j,1)=sum(sqrt((data_test1(j,:)-mean(data_test1(j,:))).^2));
        end
    end
        B(:,5)=C;  %指标4得到供货的波动率
data_get=B;
%%
%最后求到的数据在数组B中然后都进行指标的正向化
%1,2 正向指标
%3,4,5 负向指标
%6 单点最优
%7 区间最优指标
zhibiao_label=[1,1,1,1,3];
data_last=jisuan(data_get,zhibiao_label);
%A的排序结果
A_data=data_last;
%%
%%   评价指标方法选取
%层次分析法求得分
panju=[1,3,1,5,1;
    1/3,1,1/2,1,1;
    1,2,1,1,1;
    1/5,1,1,1,1;
    1,1,1,1,1];
[score_cengci,quan] = cengcifenxi(panju,A_data);
disp('层次分析法求得权重为')
disp(quan')
figure(2)
plot(score_cengci)
title('层次分析法分数')
xlabel('序号')
ylabel('得分')
hold on
%带指标权重的TPOSIS法
W=[0.2,0.2,0.2,0.2,0.2];
score_TOPSIS=TOPSIS(A_data,W);  
figure(1)
plot(score_TOPSIS)
title('TOPSIS法分数')
xlabel('序号')
ylabel('得分')
hold on
%熵权法求得分
[Score_shangquan,quan1]=shangquanfa(A_data);
disp('熵权法求得权重为')
disp(quan1)
figure(3)
plot(Score_shangquan)
title('熵权法法分数')
xlabel('序号')
ylabel('得分')
hold on

%变异系数法求得分
 [Score_bianyi,quan2]=bianyixishu(A_data);
disp('变异系数法求得权重为')
disp(quan2)
figure(4)
plot(Score_bianyi)
title('变异系数法法分数')
xlabel('序号')
ylabel('得分')
hold on
%CRITIC法求权重
[Score_CRITIC,quan3]=CRITIC(A_data);
disp('CRITIC法求得权重为')
disp(quan3)
figure(5)
plot(Score_CRITIC)
title('CRITIC法分数')
xlabel('序号')
ylabel('得分')
hold on
%%
%主成分分析法
[Score_zhuchengfen]=zhuchengfen(A_data);
figure(6)
plot(Score_zhuchengfen)
title('主成分分析法分数')
xlabel('序号')
ylabel('得分')
hold on
%%
[AAA,BBB]=sort(score_TOPSIS,'descend');
data_resultA(:,1)= data_table1( BBB,1);
data_resultA(:,2)= data_table1( BBB,2);
data_resultA(:,3)= array2table(AAA);   %排序

%%  函数部分
function data=zheng1(data1)
%正向指标1
% 填1的时候选择
data=(data1-min(data1))./(max(data1)-min(data1));
end
function data=zheng2(data1)
%正向指标2
% 填2的时候选择
data=data1;
end
function data=fu3(data1)
%负向指标1
% 填3的时候选择
data=(max(data1)-data1)./(max(data1)-min(data1));
end
function data=fu4(data1)
%负向指标2
% 填4的时候选择
data=(max(data1)-data1);
end
function data=fu5(data1)
%负向指标3
% 填5的时候选择
data=1./(max(abs(data1))+data1);
end
function data=qu6(data1,a)
%某点最优
% 填6的时候选择
data=1./(abs(data1-a)/max(abs(data1-a)));
end
function data=qu7(data1,a,b)
%区间指标1
% 填7的时候选择
for i=1:length(data1)
    if(data1>a)&&(data1<b)
        data(i)=1;
    elseif (data1<a)
        data(i)=data1/a;
    elseif (data1>b)
        data(i)=b/data1;
    end
end
end
%%
function data1=jisuan(data,zhibiao_label)
if isa(data,'double')
    for i=1:length(zhibiao_label)
        if (zhibiao_label(i)==1)
            data1(:,i)=zheng1(data(:,i));
        elseif (zhibiao_label(i)==2)
            data1(:,i)=zheng2(data(:,i));
    elseif (zhibiao_label(i)==3)
            data1(:,i)=fu3(data(:,i));
    elseif (zhibiao_label(i)==4)
            data1(:,i)=fu4(data(:,i));
   elseif (zhibiao_label(i)==5)
            data1(:,i)=fu5(data(:,i));
  elseif (zhibiao_label(i)==6)
      prompt = '这是单点最优，请输入单点最优值 ';
       a = input(prompt);
           data1(:,i)=qu6(data(:,i),a);
  elseif (zhibiao_label(i)==7)
     prompt = '这是区间最优，请输入单点最区间如[5,10] ';
      aa=prompt;
           data1(:,i)=qu7(data(:,i),aa(1),aa(2));
    end
    end
elseif isa(data,'cell')
%     data2=data;
    for j=1:length(data)
        data2=data{j};
        if size(zhibiao_label,1)==1
            zhibiao_label1=repmat(zhibiao_label,3,1);
        else
            zhibiao_label1=zhibiao_label;
       end
        for i=1:length(zhibiao_label1(j,:))
               if (zhibiao_label(i)==1)
            data1{j}(:,i)=zheng1(data2(:,i));
        elseif (zhibiao_label(i)==2)
            data1{j}(:,i)=zheng2(data2(:,i));
       elseif (zhibiao_label(i)==3)
            data1{j}(:,i)=fu3(data2(:,i));
       elseif (zhibiao_label(i)==4)
            data1{j}(:,i)=fu4(data2(:,i));
      elseif (zhibiao_label(i)==5)
            data1{j}(:,i)=fu5(data2(:,i));
     elseif (zhibiao_label(i)==6)
      prompt = '这是单点最优，请输入单点最优值 ';
       a = input(prompt);
           data1{j}(:,i)=qu6(data2(:,i),a);
    elseif (zhibiao_label(i)==7)
     prompt = '这是区间最优，请输入单点最区间如[5,10] ';
      aa=prompt;
           data1{j}(:,i)=qu7(data2(:,i),aa(1),aa(2));
    end
        end
    end
end
end
