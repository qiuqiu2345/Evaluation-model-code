%%对比性
function [Score4,quan4]=critic(A_data)
the=std(A_data);
%%矛盾性
r=corr(A_data);%corr为求相关系数
f=sum(1-r);
c=the.*f;%信息承载量
%计算权重
w=c/sum(c);
quan4=w;
%计算得分
[n,m]=size(A_data)
data=A_data./repmat(sum(A_data.*A_data).^2,n,1);%矩阵归一化
%data=mapminmax(A_data',0.002,1);%标准化到0.002-1之间
%data=data';
s=data*w';
Score4=100*s/max(s);
end
