function [Score2,quan2]=bianyi(A_data)
%标准化
data2=A_data;
for j=1:size(A_data,2)
    data2(:,j)=A_data(:,j)./sqrt(sum(A_data(:,j).^2));
end
%计算变异系数
A=mean(data2);%求每列的平均值
S=std(data2);%求每列方差
V=S./A;%变异系数
%计算权数
w=V./sum(V);
quan2=w;
%计算得分
s=data2*w';
Score2=100*s/max(s);
end