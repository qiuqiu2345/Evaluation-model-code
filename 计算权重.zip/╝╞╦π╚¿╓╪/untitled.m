clc;clear;close all
data_table1=readtable('银行数据.xlsx');
data_get=table2array(data_table1(:,3:end));
%%
%最后求到的数据在数组B中然后都进行指标的正向化
%1,2 正向指标
%3,4,5 负向指标
%6 单点最优
%7 区间最优指标
zhibiao_label=[1,1,3,3,1,1,4];  %给出指标所需要处理标签
data_last=jisuan(data_get,zhibiao_label);  %全部正向化之后的数据
A_data=data_last;
%A的排序结果
%%
%变异系数法求权重与得分
 [Score2,quan2]=bianyi(A_data);
disp('变异系数法求得权重为')
disp(quan2)
disp('变异系数法求得得分为')
disp(Score2)
%%
%熵权法求权重与得分
[Score3,quan3]=shangquan(A_data);
disp('熵权法求得权重为')
disp(quan3)
disp('熵权法求得得分为')
disp(Score3)
%%
%CRITIC法求权重与得分
[Score4,quan4]=critic1(A_data);
disp('CRITIC法求得权重为')
disp(quan4)
disp('熵权法求得得分为')
disp(Score4)
%%
