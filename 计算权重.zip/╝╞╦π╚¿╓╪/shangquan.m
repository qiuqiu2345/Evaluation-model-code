function [Score3,quan3]=shangquan(A_data)
%数据标准化到区间0.002-1
data2=mapminmax(A_data',0.002,1);
data2=data2';%得到信息熵
[m,n]=size(data2);
p=zeros(m,n);
for j=1:n
    p(:,j)=data2(:,j)/sum(data2(:,j));
end
for j=1:n
    E(j)=-1/log(m)*sum(p(:,j).*log(p(:,j)));
end
%计算权重
quan3=(1-E)/sum(1-E);
%计算得分
s=data2*quan3';
Score3=100*s/max(s);
end